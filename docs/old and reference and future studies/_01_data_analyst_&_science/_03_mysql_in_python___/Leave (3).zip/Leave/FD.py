from schema import connect

def faculty_login():
    try:
        c, con = connect()
    except Exception as e:
        print("Error in Connection as Faculty:", e)
        return

    try:
        print("1:New in Applying Leave\n2:Already having an account of leaves\n")
        access = input("What is your Choice:")
        if access == '1':
            fac_id = input("Enter Faculty ID : ")
            fac_name = input("Enter Faculty Name: ")
            fac_pass = input("Enter Your Password: ")
            fac_DOB = input("Sample: 2000-01-01\nEnter Date of Birth: ")
            fac_dept_id = input("Enter Department ID: ")
            fac_email_id = input("Enter Email ID: ")
            fac_phone_no = input("Enter Phone Number: ")
            fac_desg = input("Enter Faculty's Designation: ")
            fac_leave = int(input("Enter Number of leaves:"))
            if fac_leave < 0:
                print("Please Enter a Valid Number of Days")
            elif fac_leave < 5:
                print("Leave Approved for", fac_leave, "days")
                c.execute(
                    "INSERT INTO Faculty(ID,NAME,DEPT_ID,EMAIL,DOB,Phone_No,no_of_leaves,Password,DESIGNATION) VALUES ("
                    "%s, %s, %s, %s,"
                    "%s, %s, %s, %s,%s)",
                    (fac_id, fac_name, fac_dept_id, fac_email_id, fac_DOB, fac_phone_no, fac_leave, fac_pass, fac_desg))
                con.commit()
                print("New Faculty Registered and Leave Granted Successfully ")
            else:
                print("Need Permission from the admin or from main office")
        elif access == '2':
            print("----Enter Faculty Details for Login----")
            fac_phone_no = input("Enter Your Phone Number: ")
            fac_pass = input("Enter Your Password: ")

            c.execute("SELECT NAME,DEPT_ID FROM Faculty WHERE Phone_No=%s AND Password=%s", (fac_phone_no, fac_pass))

            fac_result = c.fetchall()
            if not fac_result:
                print("No Faculty Found")
            else:
                print("Successfully Logged In......")
                while True:
                    c.execute("SELECT NAME,DEPT_ID,no_of_leaves FROM Faculty WHERE Phone_No=%s AND Password=%s",
                              (fac_phone_no, fac_pass))

                    fac_result = c.fetchall()

                    print("1=>Applying for Leave\n"
                          "2=>Reviewing Faculty's Information\n"
                          "3=>Change of Faculty's Information\n"
                          "4=>Change of Faculty's Password\n"
                          "5=>Log Out")
                    Options = input("What is your Choice:")
                    if Options == '1':
                        leave = int(input("Enter how many days of leave are you going to take: "))
                        if leave < 0:
                            print("Please Enter a Valid Number of Days")
                        else:
                            leaves_per_semester = int(fac_result[0][2]) + leave  # Assuming fac_result is (total_leaves,)
                            if leaves_per_semester >= 0:
                                print("Leave Approved for", leave, "days")
                                # Update leaves in the database
                                update_query = "UPDATE Faculty SET no_of_leaves = %s WHERE Phone_No = %s"
                                leaves_per_semester = max(leaves_per_semester,
                                                          0)  # Ensure leaves_per_semester is not negative
                                c.execute(update_query, (leaves_per_semester, fac_phone_no))
                                con.commit()
                                print("Leave Updated. Total leave days now:",leaves_per_semester )
                            else:
                                print("Not enough leaves available")
                    elif Options == '2':
                        c.execute(
                            "SELECT ID,NAME,DEPT_ID,EMAIL,DOB,Phone_No,no_of_leaves,Password,DESIGNATION FROM Faculty")
                        details = c.fetchall()
                        print("The Details are:", details)

                    elif Options == '3':
                        print("What is the Information you want to Change:")
                        print("1=>Email Address\n"
                              "2=>Phone Number\n")
                        change = input("What is your Choice:")
                        if change == '1':
                            fac_reg = input("Enter Your Faculty ID:")
                            email = input("Enter Your New Email:")
                            c.execute("UPDATE Faculty SET EMAIL=%s WHERE ID=%s", (email, fac_reg))
                            con.commit()
                            if c.rowcount > 0:
                                print("Email Changed Successfully")
                            else:
                                print("Invalid Faculty ID")
                        elif change == '2':
                            fac_reg = input("Enter Your Faculty ID:")
                            phone = input("Enter Your New Phone Number:")
                            c.execute("UPDATE Faculty SET Phone_No=%s WHERE ID=%s", (phone, fac_reg))
                            con.commit()
                            if c.rowcount > 0:
                                print("Phone Number Changed Successfully")
                            else:
                                print("Invalid Faculty ID")
                    elif Options == '4':
                        st_id = int(input("Enter Faculty ID to change Password:"))
                        c.execute("SELECT Password FROM Faculty WHERE ID=%s", (st_id,))
                        pass_c = c.fetchone()
                        if not pass_c:
                            print("No ID found")
                        else:
                            old_pass = input("Enter The Current Password:")
                            if old_pass == pass_c[0]:
                                new_pass = input("Enter The New Password:")
                                c.execute("UPDATE Faculty SET Password=%s WHERE ID=%s", (new_pass, st_id))
                                print("Password changed Successfully......")
                                con.commit()
                    elif Options == '5':
                        break
        else:
            print("Please Enter a Valid Option.....")

    except Exception as e:
        print("Error:", e)
    finally:
        # Close the database cursor and connection
        if c:
            c.close()
        if con:
            con.close()
