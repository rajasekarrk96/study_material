import mysql.connector as mysql


def connect():
    try:
        conn = mysql.connect(
            host="localhost",
            user="root",
            password="1234",
            database="lms",
            port=3307,
            auth_plugin="mysql_native_password"
        )
        c = conn.cursor()
        return c, conn
    except Exception as e:
        print("Connection Error\n", e)


def departments():
    department, conn = connect()
    department.execute("CREATE TABLE if not exists Departments(ID INT PRIMARY KEY,NAME VARCHAR(255))")
    conn.commit()
    department.close()


def students():
    stud, conn = connect()
    stud.execute("CREATE TABLE if not exists Students("
                 "ID INT PRIMARY KEY, "
                 "NAME VARCHAR(255), "
                 "REG_NO VARCHAR(20), "
                 "DEPT_ID INT, "
                 "FOREIGN KEY (DEPT_ID) REFERENCES Departments(ID), "
                 "EMAIL VARCHAR(255))")
    conn.commit()
    stud.close()


def staff():
    faculty, conn = connect()
    faculty.execute("CREATE TABLE if not exists Faculty ("
                    "ID INT PRIMARY KEY, "
                    "NAME VARCHAR(255), "
                    "DEPT_ID INT, "
                    "FOREIGN KEY (DEPT_ID) REFERENCES Departments(ID), "
                    "EMAIL VARCHAR(255), "
                    "DESIGNATION VARCHAR(255))")
    conn.commit()
    faculty.close()


def leave_types():
    lt, conn = connect()
    lt.execute("CREATE TABLE if not exists Leave_Types("
               "ID INT PRIMARY KEY,"
               "NAME VARCHAR(255),"
               "Allowed_Days_per_Semester INT)")
    conn.commit()
    lt.close()


def leave_requests():
    lr, conn = connect()
    lr.execute("CREATE TABLE IF NOT EXISTS Leave_requests("
               "ID INT PRIMARY KEY AUTO_INCREMENT,"
               "STUDENT_ID INT,"
               "LEAVE_TYPE_ID INT,"
               "START_DATE DATE,"
               "END_DATE DATE,"
               "REASON TEXT,"
               "STATUS ENUM('Pending','Approved','Rejected') DEFAULT 'Pending',"
               "CREATED_AT DATETIME DEFAULT CURRENT_TIMESTAMP,"
               "FOREIGN KEY (STUDENT_ID) REFERENCES Students(ID),"
               "FOREIGN KEY (LEAVE_TYPE_ID) REFERENCES Leave_Types(ID))"
               )
    conn.commit()
    lr.close()


def admin():
    ad, conn = connect()
    ad.execute("CREATE TABLE IF NOT EXISTS ADMIN ("
               "Admin_ID VARCHAR(10),"
               "Admin_UserName TEXT NOT NULL,"
               "Admin_Password TEXT NOT NULL,"
               "Admin_Phone_no VARCHAR(10),"
               "Admin_Mail_ID TEXT NOT NULL,"
               "Admin_DOB DATE,"
               "CHECK(length(Admin_Phone_no) = 10 AND Admin_Mail_ID LIKE '%@%'))"
               )
    conn.commit()
    ad.close()