from schema import connect
import hashlib


def admin():
    try:
        c, con = connect()
    except Exception as e:
        print("Connection Error as admin:", e)
        return

    try:
        print("---Login Details----")
        admin_ph = input("Enter Your Phone Number:")
        admin_pass = input("Enter Your Password:")

        try:
            c.execute("SELECT * FROM admin WHERE Admin_Phone_no=%s AND Admin_Password=%s", (admin_ph, admin_pass))

            admin_result = c.fetchall()
            if not admin_result:
                print("No Admin Found")
                return
            else:
                print("------Login Successfully as Admin-------")

            admin_roles(c, con)

        except Exception as e:
            print("Fetching Error as Admin...", e)
        finally:
            c.close()
            con.close()
    except Exception as e:
        print("Admin login details error:", e)


def admin_roles(c, con):
    try:
        while True:
            print("1=>Create a New Admin")
            print("2=>View all Students Details")
            print("3=>View all Faculty Details")
            print("4=>View Particular Student Details")
            print("5=>View Particular Faculty Details")
            print("6=>Add a New Student")
            print("7=>Delete a Existing Student")
            print("8=>Add a New Faculty")
            print("9=>Delete a Faculty")
            print("10=>Delete a Admin")
            print("11=>Log Out")

            op = input("Enter your choice: ")

            if op == '1':
                create_new_admin(c, con)
            elif op == '2':
                view_all_students(c)
            elif op == '3':
                view_all_faculty(c)
            elif op == '4':
                view_particular_student(c)
            elif op == '5':
                view_particular_faculty(c)
            elif op == '6':
                add_new_student(c, con)
            elif op == '7':
                delete_existing_student(c, con)
            elif op == '8':
                add_new_faculty(c, con)
            elif op == '9':
                delete_faculty(c, con)
            elif op == '10':
                delete_admin(c, con)
            elif op == '11' or op.lower() == 'exit':
                print("Logged out Successfully....")
                break
    except Exception as e:
        print("Error in admin features:", e)


def create_new_admin(c, con):
    try:
        adm_user = input("Enter the username: ")
        adm_pass = input("Enter the password: ")
        adm_ph = input("Enter the phone number: ")
        adm_mail = input("Enter the email address: ")

        c.execute("INSERT INTO admin (Admin_UserName, Admin_Password, Admin_Phone_no, Admin_Mail_ID) VALUES (%s, %s, "
                  "%s, %s)",
                  (adm_user, adm_pass, adm_ph, adm_mail))
        con.commit()
        print("New Admin Created Successfully")
    except Exception as e:
        print("Error creating new admin:", e)


def view_all_students(c):
    try:
        c.execute("SELECT * FROM Students")
        stud_result = c.fetchall()

        for x in stud_result:
            print(x)
    except Exception as e:
        print("Error viewing all students:", e)


def view_all_faculty(c):
    try:
        c.execute("SELECT * FROM Faculty")
        fac_result = c.fetchall()

        for x in fac_result:
            print(x)
    except Exception as e:
        print("Error viewing all faculty:", e)


def view_particular_student(c):
    try:
        stud_ph = input("Enter Student Phone Number to see Information: ")

        c.execute("SELECT * FROM Students WHERE Phone_No=%s", (stud_ph,))
        stud_res = c.fetchall()

        if not stud_res:
            print("No Such Student found")
        else:
            for x in stud_res:
                print(x)
    except Exception as e:
        print("Error viewing particular student:", e)


def view_particular_faculty(c):
    try:
        fac_ph = input("Enter Faculty Phone Number to see Information: ")

        c.execute("SELECT * FROM Faculty WHERE Phone_No=%s", (fac_ph,))
        fac_res = c.fetchall()

        if not fac_res:
            print("No Such Faculty found")
        else:
            for x in fac_res:
                print(x)
    except Exception as e:
        print("Error viewing particular faculty:", e)


def add_new_student(c, con):
    try:
        student = input("Enter the Student Name: ")
        stud_ID = input("Enter Your Enrollment Number:")
        stud_pass = input("Enter the Password: ")
        stud_dob = input("Sample: 1990-01-01\nEnter date of birth: ")
        stud_reg = input("Enter Your Register Number:")
        stud_dep = input("Enter Department ID:")
        stud_mail = input("Enter the Email Address: ")
        stud_ph = input("Enter the Phone Number: ")

        c.execute("INSERT INTO Students (ID, NAME, Password, DOB, REG_NO, DEPT_ID, EMAIL, Phone_No) "
                  "VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                  (stud_ID, student, stud_pass, stud_dob, stud_reg, stud_dep, stud_mail, stud_ph))
        con.commit()
        print("New Student added successfully!")
    except Exception as e:
        print("Error adding new student:", e)


def delete_existing_student(c, con):
    try:
        stud_pho = input("Enter Student Phone Number to delete: ")
        ad_ph = input("Enter your phone number: ")
        ad_pas = input("Enter your password: ")

        # Check admin credentials
        c.execute("SELECT * FROM admin WHERE Admin_Phone_no=%s AND Admin_Password=%s", (ad_ph, ad_pas))
        admin_result = c.fetchall()
        if not admin_result:
            print("Cannot delete without proper permission")
            return

        # Check if student exists
        c.execute("SELECT * FROM Students WHERE Phone_No=%s", (stud_pho,))
        student_result = c.fetchall()
        if not student_result:
            print("No such student found")
            return

        # Confirm deletion
        cf = input("All records of student will be deleted.\n1->confirm\n2->Cancel\n")
        if cf == '1':
            c.execute("DELETE FROM Students WHERE Phone_No=%s", (stud_pho,))
            con.commit()
            print("All student details have been deleted")
        elif cf == '2':
            print("Deletion has been cancelled")
    except Exception as e:
        print("Error deleting student:", e)


def add_new_faculty(c, con):
    try:
        faculty = input("Enter the Faculty Name: ")
        fac_ID = input("Enter Faculty ID:")
        fac_dep = input("Enter Department ID:")
        fac_mail = input("Enter the Email Address: ")
        fac_dob = input("Sample: 1990-01-01\nEnter date of birth: ")
        fac_ph = input("Enter the Phone Number: ")
        fac_pass = input("Enter the Password: ")
        fac_desg = input("Enter Designation:")

        # Hash the password
        hashed_pass = hashlib.sha256(fac_pass.encode()).hexdigest()

        # Truncate the hashed password if it exceeds the maximum length allowed by the database column
        max_password_length = 8  # Assuming a maximum length of 64 characters for the hashed password
        truncated_hashed_pass = hashed_pass[:max_password_length]

        c.execute(
            "INSERT INTO Faculty (ID,NAME,DEPT_ID,EMAIL,DOB,Phone_No,Password,DESIGNATION) VALUES (%s, %s, %s, %s, "
            "%s,%s,%s,%s)",
            (fac_ID, faculty, fac_dep, fac_mail, fac_dob, fac_ph, truncated_hashed_pass, fac_desg))
        con.commit()
        print("New Faculty added successfully....")
    except Exception as e:
        print("Error adding new faculty:", e)


def delete_faculty(c, con):
    try:
        fac_pho = input("Enter Faculty Phone Number to delete: ")
        ad_ph = input("Enter your phone number: ")
        ad_pas = input("Enter your password: ")

        # Check admin credentials
        c.execute("SELECT * FROM admin WHERE Admin_Phone_no=%s AND Admin_Password=%s", (ad_ph, ad_pas))
        admin_result = c.fetchall()
        if not admin_result:
            print("Cannot delete without proper permission")
            return

        # Check if faculty exists
        c.execute("SELECT * FROM Faculty WHERE Phone_No=%s", (fac_pho,))
        faculty_result = c.fetchall()
        if not faculty_result:
            print("No such Faculty found")
            return

        # Confirm deletion
        cf = input("All records of Faculty will be Deleted\n1->Confirm\n2->Cancel\n")
        if cf == '1':
            c.execute("DELETE FROM Faculty WHERE Phone_No=%s", (fac_pho,))
            con.commit()
            print("All Faculty details have been deleted")
        elif cf == '2':
            print("Deletion has been cancelled")
    except Exception as e:
        print("Error deleting faculty:", e)


def delete_admin(c, con):
    try:
        ch_ph = input("Enter Admin phone number to delete: ")
        ad_ph = input("Enter your phone number: ")
        ad_pas = input("Enter your password: ")

        # Check admin credentials
        c.execute("SELECT * FROM admin WHERE Admin_Phone_no=%s AND Admin_Password=%s", (ad_ph, ad_pas))
        admin_result = c.fetchall()
        if not admin_result:
            print("Can't delete without proper permission")
            return

        # Check if admin to be deleted exists
        c.execute("SELECT * FROM admin WHERE Admin_Phone_no=%s", (ch_ph,))
        admin_to_delete = c.fetchall()
        if not admin_to_delete:
            print("No such Admin found")
            return

        # Confirm deletion
        cf = input("All Records of Admin will be Deleted\n1->Confirm\n2->Cancel\n")
        if cf == '1':
            c.execute("DELETE FROM admin WHERE Admin_Phone_no=%s", (ch_ph,))
            con.commit()
            print("All Admin details have been deleted")
        elif cf == '2':
            print("Deletion has been cancelled")
    except Exception as e:
        print("Error deleting admin:", e)
