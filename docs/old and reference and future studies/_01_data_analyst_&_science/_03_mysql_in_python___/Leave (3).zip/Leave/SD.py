from schema import connect, students, departments, leave_requests, leave_types



# no of days leave problem
def student_login():
    try:
        c, con = connect()
    except Exception as e:
        print("Error in Connection as Student:", e)
        return

    try:
        print("1: New Student for Applying Leave\n2:Already having an account of leaves\n")
        access = input("What is Your Choice:")
        if access == '1':
            stud_id = input("Enter Student ID or Enrollment Number: ")
            stud_name = input("Enter Student Name: ")
            stud_pass = input("Enter Your Password: ")
            stud_DOB = input("Sample: 2000-01-01\nEnter Date of Birth: ")
            stud_register_no = input("Enter Register Number: ")
            stud_dept_id = input("Enter Department ID: ")
            stud_email_id = input("Enter Email ID: ")
            stud_phone_no = input("Enter Phone Number: ")
            stud_leaves = int(input("Enter Number of Leave Days:"))
            if stud_leaves < 0:
                print("Please Enter a Valid Number of Days")
            elif stud_leaves < 5:
                print("Leave Approved for", stud_leaves, "days")
                c.execute(
                    "INSERT INTO Students(ID,NAME,Password,DOB,REG_NO,DEPT_ID,EMAIL,Phone_No,no_of_leaves) VALUES ("
                    "%s, %s, %s, %s, %s, %s, %s, %s,%s)",
                    (stud_id, stud_name, stud_pass, stud_DOB, stud_register_no, stud_dept_id, stud_email_id,
                     stud_phone_no,
                     stud_leaves))
                con.commit()
                print("New Student Registered and Leave also approved successfully")

            else:
                print("Need Permission from the admin or from main office")

        elif access == '2':
            print("----Enter Student Details for Login----")
            stud_ID = input("Enter Your Enrollment Number or ID: ")
            stud_password = input("Enter Your Password: ")

            c.execute("SELECT NAME,DEPT_ID FROM Students WHERE ID=%s AND Password=%s",
                      (stud_ID, stud_password))

            stud_result = c.fetchall()
            if not stud_result:
                print("No Student Found")
            else:
                print("Successfully Logged In......")
                while True:
                    c.execute("SELECT NAME, DEPT_ID,no_of_leaves FROM Students WHERE ID = %s AND Password = %s",
                              (stud_ID, stud_password))
                    stud_result = c.fetchall()

                    if not stud_result:
                        print("Invalid credentials. Please try again or sign up.")
                        break  # Terminate the loop if credentials are invalid

                    print("1=> Applying for Leave\n"
                          "2=> Reviewing Student's Information\n"
                          "3=> Change of Student's Information\n"
                          "4=> Change of Student's Password\n"
                          "5=> Log Out")
                    Options = input("What is your Choice:")
                    if Options == '1':
                        leave = input("Enter how many days of leave are you going to take:\n")
                        if leave < '0':
                            print("Please Enter a Valid Number of Days")
                        elif leave < '5':
                            previous_leave = int(stud_result[0][2])
                            new_leave = previous_leave + int(leave)  # Convert leave to integer before adding
                            c.execute("UPDATE students SET no_of_leaves = %s WHERE ID = %s", (new_leave, stud_ID))
                            con.commit()
                            print("Leave Updated. Total leave days now:", new_leave)
                        else:
                            print("Need Permission from the admin or from main office")
                    elif Options == '2':
                        c.execute(
                            "SELECT ID, NAME, Password, DOB, REG_NO, DEPT_ID, EMAIL, Phone_No, no_of_leaves FROM "
                            "Students")
                        details = c.fetchall()
                        print("The Details are:", details)

                    elif Options == '3':
                        print("What is the Information you want to Change:")
                        print("1=>Email Address\n"
                              "2=>Phone Number\n")
                        change = input("What is your Choice:")

                        if change == '1':
                            st_enr = input("Enter Your Enrollment Number or ID:")
                            email = input("\nEnter Your New Email:")
                            c.execute("UPDATE Students SET EMAIL=%s WHERE ID=%s", (email, st_enr))
                            con.commit()
                            if c.rowcount > 0:
                                print("Email Changed Successfully")
                            else:
                                print("Invalid Register Number")
                        elif change == '2':
                            st_enr = input("Enter Your Enrollment Number or ID:")
                            phone = input("\nEnter Your New Phone Number:")
                            c.execute("UPDATE Students SET Phone_No=%s WHERE ID=%s", (phone, st_enr))
                            con.commit()
                            if c.rowcount > 0:
                                print("Phone Number Changed Successfully")
                            else:
                                print("Invalid Register Number")
                    elif Options == '4':
                        st_id = int(input("Enter The Student ID to change Password:"))
                        c.execute("SELECT Password FROM Students WHERE ID=%s", (st_id,))
                        pass_c = c.fetchone()
                        if not pass_c:
                            print("No ID found")
                        else:
                            old_pass = input("Enter The Current Password:")
                            if old_pass == pass_c[0]:
                                new_pass = input("Enter The New Password:")
                                c.execute("UPDATE Students SET Password=%s WHERE ID=%s", (new_pass, st_id))
                                print("Password changed Successfully......")
                                con.commit()
                                student_login()
                            else:
                                print("Incorrect password. Please try again.")
                    elif Options == '5':
                        break
        else:
            print("Please Enter a Valid Option?????")

    except Exception as e:
        print("Error:", e)
    finally:
        # Close the database cursor and connection
        if c:
            c.close()
        if con:
            con.close()
