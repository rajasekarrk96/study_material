from SD import student_login
from FD import faculty_login
from Admin import admin


if __name__ == "__main__":
    print("--------WELCOME TO EDUSPHERE---------")
    try:
        while True:
            print("1->Admin\n2->Student\n3->Faculty\n4->Exit\n")
            op = input("What is Your Choice :")
            if op == '1' or op.lower() == "admin":
                admin()
            elif op == '2' or op.lower() == "student":
                student_login()
            elif op == '3' or op.lower() == 'faculty':
                faculty_login()
            elif op == '4' or op.lower() == 'exit':
                break
    except Exception as e:
        print("Error occurred:", e)

# Admin Roles:
# Admin Login
# Admin must be created mandatory so that there would be permanent Admin and No one can manipulate both admin,students,faculty data
# Once admin is created many admins can be created but the permanent can never be changed
# Admin can view both students and faculty details and number of leaves taken per semester
# Admin can view Particular Person Number of Leaves
# Admin can also create or delete a student or staff
# Admin can also delete other admin than mandatory admin

# Student and Staff Roles:
# Both can sign in and log in
# But student cannot be accessed as teacher and vice versa
# But Admin can access and even change or delete both
# For both the cases if anyone is applying for leave they must mention their start and end date and also their reason
# Both are tracked with how many leaves they have taken per semester
