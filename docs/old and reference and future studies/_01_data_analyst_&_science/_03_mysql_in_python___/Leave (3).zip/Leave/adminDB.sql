CREATE TABLE IF NOT EXISTS ADMIN (Admin_ID INTEGER PRIMARY KEY,Admin_UserName TEXT NOT NULL,
                        Admin_Password TEXT NOT NULL,
                        Admin_Phone_no VARCHAR(10),
                        Admin_Mail_ID TEXT NOT NULL,
                        CHECK(length(Admin_Phone_no) = 10 AND Admin_Mail_ID LIKE '%@%'));

SELECT * FROM lms.admin;
alter table lms.admin add column Admin_DOB date; 
describe lms.admin;
use lms;
drop table lms.admin;


insert into lms.admin(Admin_ID,Admin_UserName,Admin_Password,Admin_DOB,Admin_Phone_no,Admin_Mail_ID) values (1001,'Rajasekar','1234','1991-10-13','9003927447','raja@gmail.com');

